import os
import nltk
from src.preprocess import preprocess_directory, preprocess_text
from src.boolean_ir import build_incidence_matrix, build_inverted_index, parse_boolean_query
from src.vsm_ir import (
    load_processed_docs,
    build_tfidf,
    rank,
    precision_at_k,
    average_precision,
    ndcg_at_k
)

nltk.download('punkt', quiet=True)
nltk.download("punkt_tab", quiet=True)
nltk.download('stopwords', quiet=True)

if __name__ == "__main__":
    input_dir = os.path.join("data")
    output_dir = os.path.join("data", "processed")

    # PREPROCESSING
    #preprocess_directory(input_dir, output_dir)

    processed_docs = []
    for filename in os.listdir(output_dir):
        if filename.endswith(".txt"):
            file_path = os.path.join(output_dir, filename)
            with open(file_path, 'r', encoding='utf-8') as file:
                processed_docs.append(file.read().strip())
    
    # BOOLEAN IR
    incidence_matrix, vocabulary = build_incidence_matrix(processed_docs)
    inverted_index = build_inverted_index(processed_docs)

    query = input("Masukkan Boolean query (cont: 'cardiovascular AND knn'): ")
    result = parse_boolean_query(query, inverted_index)
    print(f"Query results: {result}")

    # VSM IR
    docs, doc_ids = load_processed_docs(output_dir)

    vectorizer, tfidf_matrix = build_tfidf(docs)

    query_vsm_raw = input("\nMasukkan query VSM: ")
    query_vsm = preprocess_text(query_vsm_raw)
    top_results = rank(query_vsm, docs, doc_ids, vectorizer, tfidf_matrix, k=5)

    print("\n=== TOP-5 VSM RANKING ===")
    for r in top_results:
        print(f"{r['doc_id']} | {r['score']:.4f} | {r['snippet']}")

    gold = ["137485529.techno.com.txt", "88974145.techno.com.txt"]
    retrieved = [r["doc_id"] for r in top_results]

    print("\n HASIL METRIK EVALUASI :")
    print("Precision@5:", precision_at_k(retrieved, gold, 5))
    print("MAP@5:", average_precision(retrieved, gold, 5))
    print("nDCG@5:", ndcg_at_k(retrieved, gold, 5))